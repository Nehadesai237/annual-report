"""
Admin endpoints for activity review and management
"""

from fastapi import APIRouter, Depends, HTTPException, status, Body
from typing import List, Optional
from datetime import datetime
from bson import ObjectId
from app.models.activity import Activity, ActivityStatus
from app.models.user import User, UserRole, UserUpdate
from app.services.activity_service import ActivityService
from app.services.user_service import UserService
from app.services.database import get_database
from app.core.security import require_admin, TokenData
from motor.motor_asyncio import AsyncIOMotorDatabase

router = APIRouter()

@router.get("/rejected", response_model=List[Activity])
async def get_rejected_activities(
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get all rejected activities for admin review"""
    activity_service = ActivityService(db)
    
    activities = await activity_service.get_rejected_activities()
    return activities

@router.get("/pending", response_model=List[Activity])
async def get_pending_activities(
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get all pending activities"""
    activity_service = ActivityService(db)
    
    activities = await activity_service.get_pending_activities()
    return activities

@router.post("/approve/{activity_id}")
async def approve_activity(
    activity_id: str,
    comments: str = None,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Approve an activity (can approve pending or rejected activities)"""
    activity_service = ActivityService(db)
    
    # Check if activity exists
    activity = await activity_service.get_by_id(activity_id)
    if not activity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Activity not found"
        )
    
    # Can approve pending or rejected activities
    if activity.status == ActivityStatus.ACCEPTED.value:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Activity is already accepted"
        )
    
    # Update status to accepted
    update_data = {
        "status": ActivityStatus.ACCEPTED.value,
        "admin_reviewed_at": datetime.utcnow(),
        "admin_reviewed_by": current_user.user_id,
        "admin_comments": comments,
        "updated_at": datetime.utcnow()
    }
    
    await activity_service.collection.update_one(
        {"_id": ObjectId(activity_id)},
        {"$set": update_data}
    )
    
    # Create notification
    from app.services.notification_service import NotificationService
    notification_service = NotificationService(db)
    await notification_service.create_notification(
        user_id=activity.user_id,
        title="Activity Approved",
        message=f"Your activity '{activity.title}' has been approved by admin.",
        type="activity_approved"
    )
    
    return {"message": "Activity approved successfully"}

@router.post("/discard/{activity_id}")
async def discard_activity(
    activity_id: str,
    comments: str = None,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Permanently discard a rejected activity"""
    activity_service = ActivityService(db)
    
    # Check if activity exists
    activity = await activity_service.get_by_id(activity_id)
    if not activity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Activity not found"
        )
    
    # Can only discard rejected activities
    if activity.status != ActivityStatus.REJECTED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Can only discard rejected activities"
        )
    
    # Discard activity
    await activity_service.discard_activity(
        activity_id, 
        current_user.user_id, 
        comments
    )
    
    return {"message": "Activity discarded successfully"}

@router.get("/stats")
async def get_admin_stats(
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get admin dashboard statistics"""
    activity_service = ActivityService(db)
    
    stats = await activity_service.get_admin_stats()
    return stats

@router.get("/audit-logs")
async def get_audit_logs(
    skip: int = 0,
    limit: int = 100,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get audit logs"""
    activity_service = ActivityService(db)
    
    logs = await activity_service.get_audit_logs(skip=skip, limit=limit)
    return logs

@router.post("/bulk-approve")
async def bulk_approve_activities(
    activity_ids: List[str],
    comments: str = None,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Bulk approve multiple activities"""
    activity_service = ActivityService(db)
    
    results = []
    for activity_id in activity_ids:
        try:
            activity = await activity_service.get_by_id(activity_id)
            if not activity:
                results.append({
                    "activity_id": activity_id,
                    "status": "error",
                    "message": "Activity not found"
                })
                continue
            
            if activity.status != ActivityStatus.REJECTED:
                results.append({
                    "activity_id": activity_id,
                    "status": "error",
                    "message": "Can only approve rejected activities"
                })
                continue
            
            await activity_service.approve_activity(
                activity_id, 
                current_user.user_id, 
                comments
            )
            
            results.append({
                "activity_id": activity_id,
                "status": "success",
                "message": "Activity approved"
            })
            
        except Exception as e:
            results.append({
                "activity_id": activity_id,
                "status": "error",
                "message": str(e)
            })
    
    return {"results": results}

@router.post("/bulk-discard")
async def bulk_discard_activities(
    activity_ids: List[str],
    comments: str = None,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Bulk discard multiple activities"""
    activity_service = ActivityService(db)
    
    results = []
    for activity_id in activity_ids:
        try:
            activity = await activity_service.get_by_id(activity_id)
            if not activity:
                results.append({
                    "activity_id": activity_id,
                    "status": "error",
                    "message": "Activity not found"
                })
                continue
            
            if activity.status != ActivityStatus.REJECTED:
                results.append({
                    "activity_id": activity_id,
                    "status": "error",
                    "message": "Can only discard rejected activities"
                })
                continue
            
            await activity_service.discard_activity(
                activity_id, 
                current_user.user_id, 
                comments
            )
            
            results.append({
                "activity_id": activity_id,
                "status": "success",
                "message": "Activity discarded"
            })
            
        except Exception as e:
            results.append({
                "activity_id": activity_id,
                "status": "error",
                "message": str(e)
            })
    
    return {"results": results}

@router.get("/all-activities")
async def get_all_activities(
    skip: int = 0,
    limit: int = 50,
    status: Optional[str] = None,
    department: Optional[str] = None,
    type: Optional[str] = None,
    year: Optional[int] = None,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get all activities with filters"""
    activity_service = ActivityService(db)
    
    # Build filters
    filters_dict = {}
    if status:
        filters_dict["status"] = status
    if department:
        filters_dict["department"] = department
    if type:
        filters_dict["type"] = type
    if year:
        filters_dict["year"] = year
    
    # Get activities
    cursor = activity_service.collection.find(filters_dict).skip(skip).limit(limit).sort("created_at", -1)
    activities = []
    
    async for activity_doc in cursor:
        activity_doc["_id"] = str(activity_doc["_id"])
        
        # Get user info
        if "user_id" in activity_doc:
            try:
                user = await db.users.find_one({"_id": ObjectId(activity_doc["user_id"])})
                if user:
                    activity_doc["user_name"] = user.get("name", "Unknown")
                    activity_doc["user_email"] = user.get("email", "")
            except:
                pass
        
        activities.append(activity_doc)
    
    total = await activity_service.collection.count_documents(filters_dict)
    
    return {
        "activities": activities,
        "total": total,
        "page": (skip // limit) + 1,
        "size": limit
    }

@router.get("/analytics")
async def get_analytics(
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get comprehensive analytics for admin dashboard"""
    activity_service = ActivityService(db)
    user_service = UserService(db)
    
    # Get activity stats
    activity_stats = await activity_service.get_admin_stats()
    
    # Get user stats
    total_users = await user_service.get_user_count()
    department_stats = await user_service.get_department_stats()
    
    # Get activities by month
    monthly_pipeline = [
        {
            "$group": {
                "_id": {
                    "year": {"$year": "$created_at"},
                    "month": {"$month": "$created_at"}
                },
                "count": {"$sum": 1}
            }
        },
        {"$sort": {"_id.year": 1, "_id.month": 1}},
        {"$limit": 12}
    ]
    
    monthly_activities = []
    async for doc in activity_service.collection.aggregate(monthly_pipeline):
        monthly_activities.append({
            "year": doc["_id"]["year"],
            "month": doc["_id"]["month"],
            "count": doc["count"]
        })
    
    # Get activities by type
    type_pipeline = [
        {
            "$group": {
                "_id": "$type",
                "count": {"$sum": 1}
            }
        },
        {"$sort": {"count": -1}}
    ]
    
    type_stats = []
    async for doc in activity_service.collection.aggregate(type_pipeline):
        type_stats.append({
            "type": doc["_id"],
            "count": doc["count"]
        })
    
    # Get department activity distribution
    dept_activity_pipeline = [
        {
            "$group": {
                "_id": "$department",
                "total": {"$sum": 1},
                "accepted": {
                    "$sum": {"$cond": [{"$eq": ["$status", "accepted"]}, 1, 0]}
                },
                "pending": {
                    "$sum": {"$cond": [{"$eq": ["$status", "pending"]}, 1, 0]}
                },
                "rejected": {
                    "$sum": {"$cond": [{"$eq": ["$status", "rejected"]}, 1, 0]}
                }
            }
        },
        {"$sort": {"total": -1}}
    ]
    
    dept_distribution = []
    async for doc in activity_service.collection.aggregate(dept_activity_pipeline):
        dept_distribution.append({
            "department": doc["_id"],
            "total": doc["total"],
            "accepted": doc["accepted"],
            "pending": doc["pending"],
            "rejected": doc["rejected"]
        })
    
    # Get user roles distribution
    users_by_role = {}
    role_pipeline = [
        {"$group": {"_id": "$role", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]
    
    async for doc in user_service.collection.aggregate(role_pipeline):
        users_by_role[doc["_id"]] = doc["count"]
    
    return {
        "activity_stats": activity_stats,
        "total_users": total_users,
        "users_by_role": users_by_role,
        "monthly_activities": monthly_activities,
        "type_distribution": type_stats,
        "department_distribution": dept_distribution,
        "department_user_stats": department_stats
    }

@router.get("/users/all")
async def get_all_users(
    skip: int = 0,
    limit: int = 50,
    role: Optional[str] = None,
    department: Optional[str] = None,
    search: Optional[str] = None,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get all users with filters"""
    user_service = UserService(db)
    
    # Build filter
    users = await user_service.get_users(
        skip=skip,
        limit=limit,
        department=department,
        role=UserRole(role) if role else None,
        active_only=False
    )
    
    # Apply search filter
    if search:
        search_lower = search.lower()
        users = [u for u in users if search_lower in u.name.lower() or search_lower in u.email.lower()]
    
    # Get total count
    total = await user_service.collection.count_documents({})
    
    # Get activity count for each user and convert to dict
    activity_service = ActivityService(db)
    result_users = []
    for user in users:
        activity_count = await activity_service.collection.count_documents({"user_id": user.id})
        # Convert User to dict
        user_dict = {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "department": user.department,
            "role": user.role.value if hasattr(user.role, 'value') else user.role,
            "student_id": user.student_id,
            "phone": user.phone,
            "year_of_study": user.year_of_study,
            "is_active": user.is_active,
            "email_verified": user.email_verified,
            "last_login": user.last_login,
            "created_at": user.created_at,
            "updated_at": user.updated_at,
            "activity_count": activity_count
        }
        result_users.append(user_dict)
    
    return {
        "users": result_users,
        "total": total,
        "page": (skip // limit) + 1,
        "size": limit
    }

@router.post("/users/{user_id}/toggle-status")
async def toggle_user_status(
    user_id: str,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Activate or deactivate a user"""
    user_service = UserService(db)
    
    # Get user
    user = await user_service.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Cannot deactivate self
    if user_id == current_user.user_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot deactivate your own account"
        )
    
    # Toggle status
    new_status = not user.is_active
    await user_service.update_user(user_id, UserUpdate(is_active=new_status))
    
    return {"message": f"User {('activated' if new_status else 'deactivated')} successfully"}

@router.post("/activities/{activity_id}/reject")
async def reject_activity(
    activity_id: str,
    body: Optional[dict] = Body(default=None),
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Reject an activity"""
    activity_service = ActivityService(db)
    
    # Get comments from body
    comments = body.get("comments") if body and isinstance(body, dict) else None
    
    # Check if activity exists
    activity = await activity_service.get_by_id(activity_id)
    if not activity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Activity not found"
        )
    
    # Can reject pending activities
    if activity.status == ActivityStatus.REJECTED.value:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Activity is already rejected"
        )
    
    # Update status
    update_data = {
        "status": ActivityStatus.REJECTED.value,
        "admin_reviewed_at": datetime.utcnow(),
        "admin_reviewed_by": current_user.user_id,
        "admin_comments": comments,
        "updated_at": datetime.utcnow()
    }
    
    await activity_service.collection.update_one(
        {"_id": ObjectId(activity_id)},
        {"$set": update_data}
    )
    
    # Create notification
    from app.services.notification_service import NotificationService
    notification_service = NotificationService(db)
    await notification_service.create_notification(
        user_id=activity.user_id,
        title="Activity Rejected",
        message=f"Your activity '{activity.title}' has been rejected." + (f" Comments: {comments}" if comments else ""),
        type="activity_rejected"
    )
    
    return {"message": "Activity rejected successfully"}

@router.get("/departments")
async def get_all_departments(
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get all departments"""
    departments_pipeline = [
        {"$group": {"_id": "$department"}},
        {"$sort": {"_id": 1}}
    ]
    
    departments = []
    async for doc in db.users.aggregate(departments_pipeline):
        departments.append(doc["_id"])
    
    return {"departments": departments}
