import React from 'react';
import { 
  FaMapMarkerAlt, 
  FaPhone, 
  FaEnvelope,
  FaFacebook,
  FaTwitter,
  FaInstagram,
  FaLinkedin
} from 'react-icons/fa';

const ContactSection = ({ isVisible }) => {
  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          data-animate
          className={`text-center mb-16 transition-all duration-1000 ${isVisible['contact-title'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          id="contact-title"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Get In Touch</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to join our community? Contact us for more information about admissions and programs.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div 
            data-animate
            className={`transition-all duration-1000 delay-100 ${isVisible['contact-info'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            id="contact-info"
          >
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">Contact Information</h3>
            <div className="space-y-4">
              <div className="flex items-center">
                <FaMapMarkerAlt className="h-5 w-5 text-blue-600 mr-3" />
                 <span className="text-gray-700">TKIET Warananagar, Kolhapur, Maharashtra, India</span>
              </div>
              <div className="flex items-center">
                <FaPhone className="h-5 w-5 text-blue-600 mr-3" />
                <span className="text-gray-700">+91-XXX-XXXX-XXXX</span>
              </div>
              <div className="flex items-center">
                <FaEnvelope className="h-5 w-5 text-blue-600 mr-3" />
                 <span className="text-gray-700">info@tkiet.edu.in</span>
              </div>
            </div>
            
            <div className="mt-8">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-blue-600 hover:text-blue-800 transition-colors">
                  <FaFacebook className="h-6 w-6" />
                </a>
                <a href="#" className="text-blue-600 hover:text-blue-800 transition-colors">
                  <FaTwitter className="h-6 w-6" />
                </a>
                <a href="#" className="text-blue-600 hover:text-blue-800 transition-colors">
                  <FaInstagram className="h-6 w-6" />
                </a>
                <a href="#" className="text-blue-600 hover:text-blue-800 transition-colors">
                  <FaLinkedin className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
          
          <div 
            data-animate
            className={`transition-all duration-1000 delay-200 ${isVisible['contact-form'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            id="contact-form"
          >
            <div className="bg-white rounded-lg shadow-md p-8">
              <h3 className="text-2xl font-semibold text-gray-900 mb-6">Send us a Message</h3>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                  <input 
                    type="text" 
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input 
                    type="email" 
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="your.email@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                  <textarea 
                    rows="4"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Your message"
                  ></textarea>
                </div>
                <button 
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md font-semibold transition-colors"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
