import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FiArrowLeft, FiCalendar, FiTag, FiImage, FiCheckCircle, FiClock, FiXCircle, FiEdit, FiTrash2, FiDownload, FiEye, FiFileText, FiUser, FiAward } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';
import axios from 'axios';

const ActivityDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activity, setActivity] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [imageModal, setImageModal] = useState({ isOpen: false, image: null });

  useEffect(() => {
    fetchActivity();
  }, [id]);

  const fetchActivity = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`http://localhost:8000/api/v1/activities/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      setActivity(response.data);
    } catch (error) {
      console.error('Error fetching activity:', error);
      toast.error('Failed to fetch achievement details');
      navigate('/activities');
    } finally {
      setLoading(false);
    }
  };

  const getStatusInfo = (status) => {
    switch (status) {
      case 'accepted':
        return { icon: FiCheckCircle, color: 'bg-green-100 text-green-800', borderColor: 'border-green-300', bgColor: 'bg-green-50' };
      case 'rejected':
        return { icon: FiXCircle, color: 'bg-red-100 text-red-800', borderColor: 'border-red-300', bgColor: 'bg-red-50' };
      case 'pending':
        return { icon: FiClock, color: 'bg-yellow-100 text-yellow-800', borderColor: 'border-yellow-300', bgColor: 'bg-yellow-50' };
      default:
        return { icon: FiClock, color: 'bg-gray-100 text-gray-800', borderColor: 'border-gray-300', bgColor: 'bg-gray-50' };
    }
  };

  const getTypeColor = (type) => {
    const colors = {
      social: 'bg-blue-100 text-blue-800',
      sports: 'bg-green-100 text-green-800',
      academic: 'bg-purple-100 text-purple-800',
      cultural: 'bg-pink-100 text-pink-800',
      technical: 'bg-indigo-100 text-indigo-800'
    };
    return colors[type] || 'bg-gray-100 text-gray-800';
  };

  const handleDelete = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8000/api/v1/activities/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      toast.success('Achievement deleted successfully');
      navigate('/activities');
    } catch (error) {
      console.error('Error deleting activity:', error);
      toast.error(error.response?.data?.detail || 'Failed to delete achievement');
    }
  };

  const handleEdit = () => {
    navigate(`/activities/${id}/edit`);
  };

  const openImageModal = (image) => {
    setImageModal({ isOpen: true, image });
  };

  const closeImageModal = () => {
    setImageModal({ isOpen: false, image: null });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="text-center">
          <div className="spinner mb-4"></div>
          <p className="text-gray-600">Loading achievement details...</p>
        </div>
      </div>
    );
  }

  if (!activity) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Achievement Not Found</h2>
          <p className="text-gray-600 mb-6">The achievement you're looking for doesn't exist.</p>
          <button
            onClick={() => navigate('/activities')}
            className="btn-primary"
          >
            Back to Achievements
          </button>
        </div>
      </div>
    );
  }

  const statusInfo = getStatusInfo(activity.status);
  const StatusIcon = statusInfo.icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => navigate('/activities')}
            className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6 transition-colors font-medium"
          >
            <FiArrowLeft className="w-5 h-5 mr-2" />
            Back to Achievements
          </button>
          
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-bold uppercase tracking-wide ${statusInfo.color}`}>
                  <StatusIcon className="h-4 w-4 mr-2" />
                  {activity.status}
                </span>
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold ${getTypeColor(activity.type)}`}>
                  {activity.type}
                </span>
              </div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-3">
                {activity.title}
              </h1>
              <p className="text-gray-600 text-lg">{activity.description}</p>
            </div>
            
            {/* Action Buttons */}
            {activity.status !== 'accepted' && (
              <div className="flex gap-3">
                <button
                  onClick={handleEdit}
                  className="inline-flex items-center px-6 py-3 bg-white border-2 border-blue-600 text-blue-600 font-semibold rounded-xl shadow-lg hover:shadow-xl hover:bg-blue-600 hover:text-white transition-all duration-200"
                >
                  <FiEdit className="h-5 w-5 mr-2" />
                  Edit
                </button>
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="inline-flex items-center px-6 py-3 bg-red-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:bg-red-700 transition-all duration-200"
                >
                  <FiTrash2 className="h-5 w-5 mr-2" />
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Images Gallery */}
            {activity.images && activity.images.length > 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                  <FiImage className="h-6 w-6 mr-3 text-blue-600" />
                  Achievement Photos ({activity.images.length})
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {activity.images.map((image, index) => {
                    const imageUrl = image.path 
                      ? `http://localhost:8000/${image.path}` 
                      : image.url 
                        ? (image.url.startsWith('http') ? image.url : `http://localhost:8000/${image.url}`)
                        : '/placeholder.jpg';
                    return (
                      <div key={index} className="relative group">
                        <img
                          src={imageUrl}
                          alt={`Achievement photo ${index + 1}`}
                          className="w-full h-48 object-cover rounded-xl shadow-md hover:shadow-xl transition-shadow cursor-pointer"
                          onClick={() => openImageModal(image)}
                        />
                        {image.ml_verified !== undefined && (
                          <div className={`absolute top-2 right-2 px-2 py-1 rounded-lg text-xs font-bold ${
                            image.ml_verified ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
                          }`}>
                            {image.ml_verified ? 'Verified' : 'Unverified'}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Certificate Section */}
            {activity.has_certificate && activity.certificate_path && (
              <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                  <FiAward className="h-6 w-6 mr-3 text-yellow-600" />
                  Certificate
                  {activity.certificate_validated && (
                    <span className="ml-3 px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-bold">
                      ✓ Verified
                    </span>
                  )}
                </h2>
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-yellow-50 to-amber-50 rounded-xl border-2 border-yellow-200">
                  <div className="flex items-center space-x-4">
                    <FiFileText className="h-12 w-12 text-yellow-600" />
                    <div>
                      <p className="font-bold text-gray-900">Official Certificate</p>
                      <p className="text-sm text-gray-600">Click to view or download</p>
                    </div>
                  </div>
                  <a
                    href={`http://localhost:8000/${activity.certificate_path}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-4 py-2 bg-yellow-600 text-white font-semibold rounded-lg hover:bg-yellow-700 transition-all"
                  >
                    <FiDownload className="h-5 w-5 mr-2" />
                    Download
                  </a>
                </div>
                <div className="mt-4">
                  <a
                    href={`http://localhost:8000/${activity.certificate_path}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <img
                      src={`http://localhost:8000/${activity.certificate_path}`}
                      alt="Certificate"
                      className="w-full h-auto rounded-xl shadow-md cursor-pointer hover:shadow-xl transition-shadow"
                    />
                  </a>
                </div>
              </div>
            )}

            {/* ML Analysis */}
            {activity.ml_analysis && (
              <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">AI Verification Analysis</h2>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <span className="text-gray-700 font-semibold">Confidence Score:</span>
                    <span className="text-blue-600 font-bold text-lg">
                      {Math.round(activity.ml_analysis.confidence * 100)}%
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <span className="text-gray-700 font-semibold">AI Prediction:</span>
                    <span className="text-blue-600 font-bold capitalize">{activity.ml_analysis.prediction}</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <span className="text-gray-700 font-semibold">Verification Status:</span>
                    <span className={`font-bold ${activity.ml_analysis.verified ? 'text-green-600' : 'text-red-600'}`}>
                      {activity.ml_analysis.verified ? 'Verified ✓' : 'Not Verified ✗'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Admin Comments */}
            {activity.admin_comments && (
              <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                  <FiUser className="h-6 w-6 mr-3 text-purple-600" />
                  Admin Feedback
                </h2>
                <div className={`p-4 ${statusInfo.bgColor} rounded-xl border-2 ${statusInfo.borderColor}`}>
                  <p className="text-gray-800 leading-relaxed">{activity.admin_comments}</p>
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Sidebar */}
          <div className="space-y-6">
            {/* Details Card */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Details</h3>
              <div className="space-y-4">
                <div className="flex items-center text-gray-600">
                  <FiCalendar className="w-5 h-5 mr-3 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-500">Created</p>
                    <p className="font-semibold text-gray-900">
                      {new Date(activity.created_at).toLocaleDateString('en-US', { 
                        month: 'long', 
                        day: 'numeric', 
                        year: 'numeric' 
                      })}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center text-gray-600">
                  <FiTag className="w-5 h-5 mr-3 text-purple-600" />
                  <div>
                    <p className="text-xs text-gray-500">Department</p>
                    <p className="font-semibold text-gray-900">{activity.department}</p>
                  </div>
                </div>
                
                <div className="flex items-center text-gray-600">
                  <FiCalendar className="w-5 h-5 mr-3 text-green-600" />
                  <div>
                    <p className="text-xs text-gray-500">Year</p>
                    <p className="font-semibold text-gray-900">{activity.year}</p>
                  </div>
                </div>

                {activity.images && activity.images.length > 0 && (
                  <div className="flex items-center text-gray-600">
                    <FiImage className="w-5 h-5 mr-3 text-indigo-600" />
                    <div>
                      <p className="text-xs text-gray-500">Total Images</p>
                      <p className="font-semibold text-gray-900">{activity.images.length}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Status Timeline */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Status Timeline</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0">
                    <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-gray-900">Submitted</p>
                    <p className="text-xs text-gray-500">
                      {new Date(activity.created_at).toLocaleString()}
                    </p>
                  </div>
                </div>
                {activity.ml_checked_at && (
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0">
                      <div className="w-3 h-3 bg-indigo-600 rounded-full"></div>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-900">ML Verified</p>
                      <p className="text-xs text-gray-500">
                        {new Date(activity.ml_checked_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                )}
                {activity.admin_reviewed_at && (
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0">
                      <div className={`w-3 h-3 rounded-full ${
                        activity.status === 'accepted' ? 'bg-green-600' : 
                        activity.status === 'rejected' ? 'bg-red-600' : 'bg-yellow-600'
                      }`}></div>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-900">Admin Reviewed</p>
                      <p className="text-xs text-gray-500">
                        {new Date(activity.admin_reviewed_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Image Modal */}
      {imageModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75" onClick={closeImageModal}>
          <div className="relative max-w-4xl max-h-[90vh] m-4" onClick={(e) => e.stopPropagation()}>
            <img
              src={
                imageModal.image.path 
                  ? `http://localhost:8000/${imageModal.image.path}` 
                  : imageModal.image.url 
                    ? (imageModal.image.url.startsWith('http') ? imageModal.image.url : `http://localhost:8000/${imageModal.image.url}`)
                    : '/placeholder.jpg'
              }
              alt="Full size"
              className="max-w-full max-h-[90vh] rounded-xl shadow-2xl"
            />
            <button
              onClick={closeImageModal}
              className="absolute top-4 right-4 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100"
            >
              <svg className="w-6 h-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setShowDeleteConfirm(false)}>
          <div className="bg-white rounded-2xl shadow-2xl p-6 max-w-md w-full m-4" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Confirm Deletion</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this achievement? This action cannot be undone.
            </p>
            <div className="flex space-x-4">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 px-4 py-3 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  handleDelete();
                }}
                className="flex-1 px-4 py-3 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-all"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ActivityDetail;

