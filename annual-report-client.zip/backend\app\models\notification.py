"""
Notification model and schemas
"""

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from enum import Enum
from bson import ObjectId

class NotificationType(str, Enum):
    """Notification types enum"""
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    ERROR = "error"
    ACTIVITY_APPROVED = "activity_approved"
    ACTIVITY_REJECTED = "activity_rejected"
    ACTIVITY_DISCARDED = "activity_discarded"

class NotificationBase(BaseModel):
    """Base notification schema"""
    title: str = Field(..., min_length=1, max_length=200)
    message: str = Field(..., min_length=1, max_length=1000)
    type: NotificationType = NotificationType.INFO

class NotificationCreate(NotificationBase):
    """Notification creation schema"""
    user_id: str

class NotificationInDB(NotificationBase):
    """Notification in database schema"""
    id: str = Field(alias="_id")
    user_id: str
    read: bool = False
    created_at: datetime
    
    class Config:
        populate_by_name = True

class Notification(NotificationBase):
    """Notification response schema"""
    id: str = Field(alias="_id")
    user_id: str
    read: bool
    created_at: datetime
    
    class Config:
        populate_by_name = True

class NotificationList(BaseModel):
    """Notification list response schema"""
    notifications: list[Notification]
    total: int
    unread_count: int
