import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import { NotificationProvider } from './contexts/NotificationContext';
import ProtectedRoute from './components/ProtectedRoute';
import Navbar from './components/Navbar';
import LandingPage from './pages/LandingPage';
import IntegratedLandingPage from './pages/IntegratedLandingPage';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Activities from './pages/Activities';
import CreateActivity from './pages/CreateActivity';
import EditActivity from './pages/EditActivity';
import ActivityDetail from './pages/ActivityDetail';
import AdminPanel from './pages/AdminPanel';
import Reports from './pages/Reports';
import Profile from './pages/Profile';
import './App.css';

function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <Router>
          <div className="App">
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<IntegratedLandingPage />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              
              {/* Redirect old dashboard to home */}
              <Route path="/dashboard" element={<Navigate to="/" replace />} />
              
              <Route path="/activities" element={
                <ProtectedRoute>
                  <div>
                    <Navbar />
                    <main className="min-h-screen bg-gray-50">
                      <Activities />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/activities/create" element={
                <ProtectedRoute>
                  <div>
                    <Navbar />
                    <main className="min-h-screen bg-gray-50">
                      <CreateActivity />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/activities/:id" element={
                <ProtectedRoute>
                  <div>
                    <Navbar />
                    <main className="min-h-screen bg-gray-50">
                      <ActivityDetail />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/activities/:id/edit" element={
                <ProtectedRoute>
                  <div>
                    <Navbar />
                    <main className="min-h-screen bg-gray-50">
                      <EditActivity />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/admin" element={
                <ProtectedRoute requireRole="admin">
                  <div>
                    <Navbar />
                    <main className="min-h-screen bg-gray-50">
                      <AdminPanel />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/reports" element={
                <ProtectedRoute>
                  <div>
                    <Navbar />
                    <main className="min-h-screen bg-gray-50">
                      <Reports />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/profile" element={
                <ProtectedRoute>
                  <div>
                    <Navbar />
                    <main className="min-h-screen bg-gray-50">
                      <Profile />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              {/* Catch all route */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
            <Toaster 
              position="top-right"
              toastOptions={{
                duration: 4000,
                style: {
                  background: '#363636',
                  color: '#fff',
                },
                success: {
                  duration: 3000,
                  iconTheme: {
                    primary: '#4ade80',
                    secondary: '#fff',
                  },
                },
                error: {
                  duration: 5000,
                  iconTheme: {
                    primary: '#ef4444',
                    secondary: '#fff',
                  },
                },
              }}
            />
          </div>
        </Router>
      </NotificationProvider>
    </AuthProvider>
  );
}

export default App;
