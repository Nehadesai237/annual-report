import axios from 'axios';

// Get API URL from environment or use default
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // If unauthorized, clear token and redirect to login
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

/**
 * Authentication Service
 * Handles all authentication-related API calls
 */
const authService = {
  /**
   * Login user
   * @param {string} email - User email
   * @param {string} password - User password
   * @param {boolean} rememberMe - Remember me option
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  async login(email, password, rememberMe = false) {
    try {
      const response = await api.post('/api/v1/auth/login', {
        email,
        password,
        remember_me: rememberMe
      });
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      return {
        success: false,
        error: this.getErrorMessage(error)
      };
    }
  },

  /**
   * Register new user
   * @param {object} userData - User registration data
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  async register(userData) {
    try {
      const response = await api.post('/api/v1/auth/register', userData);
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      return {
        success: false,
        error: this.getErrorMessage(error)
      };
    }
  },

  /**
   * Get current user
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  async getCurrentUser() {
    try {
      const response = await api.get('/api/v1/auth/me');
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      return {
        success: false,
        error: this.getErrorMessage(error)
      };
    }
  },

  /**
   * Update user profile
   * @param {object} userData - Updated user data
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  async updateProfile(userData) {
    try {
      const response = await api.put('/api/v1/auth/me', userData);
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      return {
        success: false,
        error: this.getErrorMessage(error)
      };
    }
  },

  /**
   * Change user password
   * @param {string} currentPassword - Current password
   * @param {string} newPassword - New password
   * @param {string} confirmPassword - Confirm password
   * @returns {Promise<{success: boolean, error?: string}>}
   */
  async changePassword(currentPassword, newPassword, confirmPassword) {
    try {
      await api.post('/api/v1/auth/change-password', {
        current_password: currentPassword,
        new_password: newPassword,
        confirm_password: confirmPassword
      });
      
      return {
        success: true
      };
    } catch (error) {
      return {
        success: false,
        error: this.getErrorMessage(error)
      };
    }
  },

  /**
   * Refresh access token
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  async refreshToken() {
    try {
      const response = await api.post('/api/v1/auth/refresh');
      
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      return {
        success: false,
        error: this.getErrorMessage(error)
      };
    }
  },

  /**
   * Logout user
   * @returns {Promise<{success: boolean, error?: string}>}
   */
  async logout() {
    try {
      await api.post('/api/v1/auth/logout');
      
      return {
        success: true
      };
    } catch (error) {
      // Even if logout fails on server, clear local storage
      return {
        success: true
      };
    }
  },

  /**
   * Extract error message from API response
   * @param {Error} error - Error object
   * @returns {string} - Error message
   */
  getErrorMessage(error) {
    if (error.response?.data) {
      const data = error.response.data;
      
      // Check for detail field (FastAPI default)
      if (data.detail) {
        return data.detail;
      }
      
      // Check for message field
      if (data.message) {
        return data.message;
      }
      
      // Check for error field with message
      if (data.error?.message) {
        return data.error.message;
      }
      
      // Check for error field (string)
      if (data.error) {
        return typeof data.error === 'string' ? data.error : JSON.stringify(data.error);
      }
      
      // If no specific error, return generic message
      return 'An error occurred';
    }
    
    if (error.message) {
      return error.message;
    }
    
    return 'An unexpected error occurred';
  }
};

export default authService;

