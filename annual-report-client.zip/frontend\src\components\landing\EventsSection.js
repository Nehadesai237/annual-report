import React from 'react';
import { FaCalendarAlt } from 'react-icons/fa';

const EventsSection = ({ isVisible }) => {
  const events = [
    {
      id: 1,
      title: "Annual Technical Festival - TechFest 2024",
      date: "March 15-17, 2024",
      description: "Three days of technical competitions, workshops, and exhibitions",
      image: "/api/placeholder/400/250",
      type: "Technical"
    },
    {
      id: 2,
      title: "Cultural Festival - Utsav 2024",
      date: "February 20-22, 2024",
      description: "Celebrating arts, music, dance, and cultural diversity",
      image: "/api/placeholder/400/250",
      type: "Cultural"
    },
    {
      id: 3,
      title: "Sports Week 2024",
      date: "January 10-15, 2024",
      description: "Inter-college sports competitions and athletic events",
      image: "/api/placeholder/400/250",
      type: "Sports"
    },
    {
      id: 4,
      title: "Industry Expert Lecture Series",
      date: "Ongoing",
      description: "Regular sessions with industry leaders and experts",
      image: "/api/placeholder/400/250",
      type: "Academic"
    }
  ];

  return (
    <section id="events" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          data-animate
          className={`text-center mb-16 transition-all duration-1000 ${isVisible['events-title'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          id="events-title"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Upcoming Events</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join us for exciting events, competitions, and celebrations throughout the year.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {events.map((event, index) => (
            <div 
              key={event.id}
              data-animate
              className={`bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden transform hover:-translate-y-2 transition-all duration-1000 delay-${index * 100} ${isVisible[`event-${event.id}`] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
              id={`event-${event.id}`}
            >
              <div className="h-48 bg-gradient-to-br from-blue-400 to-indigo-600 flex items-center justify-center">
                <FaCalendarAlt className="h-16 w-16 text-white" />
              </div>
              <div className="p-6">
                <div className="text-sm text-blue-600 font-semibold mb-2">{event.type}</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{event.title}</h3>
                <p className="text-gray-600 text-sm mb-3">{event.description}</p>
                <div className="text-xs text-gray-500">{event.date}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EventsSection;
