import React, { useState, useEffect, useCallback } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FiPlus, FiEye, FiEdit, FiTrash2, FiSearch, FiFilter, FiCalendar, FiTag, FiImage, FiCheckCircle, FiClock, FiXCircle, FiArrowRight } from 'react-icons/fi';
import axios from 'axios';
import toast from 'react-hot-toast';

const Activities = () => {
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    type: '',
    status: '',
    year: '',
    search: ''
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [showFilters, setShowFilters] = useState(false);

  const loadActivities = useCallback(async () => {
    try {
      setLoading(true);
      
      // Filter out empty values from filters
      const cleanedFilters = Object.entries(filters).reduce((acc, [key, value]) => {
        if (value && value.trim() !== '') {
          acc[key] = value;
        }
        return acc;
      }, {});
      
      const params = new URLSearchParams({
        page: currentPage,
        size: 10,
        ...cleanedFilters
      });
      
      const token = localStorage.getItem('token');
      const response = await axios.get(`http://localhost:8000/api/v1/activities?${params}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      setActivities(response.data.activities || []);
      setTotalPages(response.data.pages || 1);
    } catch (error) {
      console.error('Error loading activities:', error);
      if (error.response?.status === 401) {
        toast.error('Session expired. Please login again.');
        localStorage.removeItem('token');
        window.location.href = '/login';
      }
    } finally {
      setLoading(false);
    }
  }, [currentPage, filters]);

  useEffect(() => {
    loadActivities();
  }, [loadActivities, location.pathname]);

  const handleFilterChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value
    });
    setCurrentPage(1);
  };

  const handleSearch = (e) => {
    setFilters({
      ...filters,
      search: e.target.value
    });
    setCurrentPage(1);
  };

  const deleteActivity = async (activityId) => {
    if (!window.confirm('Are you sure you want to delete this activity?')) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8000/api/v1/activities/${activityId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      toast.success('Activity deleted successfully');
      loadActivities();
    } catch (error) {
      console.error('Error deleting activity:', error);
      const message = error.response?.data?.detail || 'Failed to delete activity';
      toast.error(message);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: 'status-pending',
      accepted: 'status-accepted',
      rejected: 'status-rejected'
    };
    return colors[status] || 'status-pending';
  };

  const getTypeColor = (type) => {
    const colors = {
      social: 'type-social',
      sports: 'type-sports',
      academic: 'type-academic',
      cultural: 'type-cultural',
      technical: 'type-technical'
    };
    return colors[type] || 'type-social';
  };

  const getStatusInfo = (status) => {
    switch (status) {
      case 'accepted':
        return { icon: FiCheckCircle, color: 'bg-green-100 text-green-800 border-green-200', bgColor: 'bg-green-50', textColor: 'text-green-700' };
      case 'rejected':
        return { icon: FiXCircle, color: 'bg-red-100 text-red-800 border-red-200', bgColor: 'bg-red-50', textColor: 'text-red-700' };
      case 'pending':
        return { icon: FiClock, color: 'bg-yellow-100 text-yellow-800 border-yellow-200', bgColor: 'bg-yellow-50', textColor: 'text-yellow-700' };
      default:
        return { icon: FiClock, color: 'bg-gray-100 text-gray-800 border-gray-200', bgColor: 'bg-gray-50', textColor: 'text-gray-700' };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="text-center">
          <div className="spinner mb-4"></div>
          <p className="text-gray-600">Loading achievements...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Modern Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                My Achievements
              </h1>
              <p className="mt-2 text-gray-600 text-lg">
                Track and manage your accomplishments and their review status
              </p>
            </div>
            <Link
              to="/activities/create"
              className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200"
            >
              <FiPlus className="h-5 w-5 mr-2" />
              Share New Achievement
            </Link>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <FiSearch className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              placeholder="Search your achievements..."
              value={filters.search}
              onChange={handleSearch}
            />
          </div>
        </div>

        {/* Filter Toggle */}
        <div className="mb-6">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="inline-flex items-center px-4 py-2 bg-white border-2 border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-all text-gray-700"
          >
            <FiFilter className="h-4 w-4 mr-2" />
            Filters
            <span className="ml-2 px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
              {Object.values(filters).filter(v => v).length - 1}
            </span>
          </button>
        </div>

        {/* Collapsible Filters */}
        {showFilters && (
          <div className="mb-6 bg-white rounded-xl shadow-lg p-6 border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Category</label>
                <select
                  name="type"
                  className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  value={filters.type}
                  onChange={handleFilterChange}
                >
                  <option value="">All Categories</option>
                  <option value="academic">Academic Excellence</option>
                  <option value="technical">Technical Innovation</option>
                  <option value="cultural">Cultural & Arts</option>
                  <option value="sports">Sports & Fitness</option>
                  <option value="social">Social Service</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Status</label>
                <select
                  name="status"
                  className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  value={filters.status}
                  onChange={handleFilterChange}
                >
                  <option value="">All Statuses</option>
                  <option value="pending">Pending</option>
                  <option value="accepted">Accepted</option>
                  <option value="rejected">Rejected</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Year</label>
                <select
                  name="year"
                  className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  value={filters.year}
                  onChange={handleFilterChange}
                >
                  <option value="">All Years</option>
                  <option value="2024">2024</option>
                  <option value="2023">2023</option>
                  <option value="2022">2022</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Activities Grid */}
        {activities.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {activities.map((activity) => {
              const statusInfo = getStatusInfo(activity.status);
              const StatusIcon = statusInfo.icon;
              
              return (
                <div
                  key={activity.id}
                  className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border-2 border-transparent hover:border-blue-200 cursor-pointer group"
                  onClick={() => navigate(`/activities/${activity.id}`)}
                >
                  {/* Card Header with Gradient */}
                  <div className="h-2 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500"></div>
                  
                  <div className="p-6">
                    {/* Status Badge */}
                    <div className="flex items-center justify-between mb-4">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${statusInfo.color} border-2`}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {activity.status}
                      </span>
                      <span className={`type-badge ${getTypeColor(activity.type)} font-semibold`}>
                        {activity.type}
                      </span>
                    </div>
                    
                    {/* Title */}
                    <h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
                      {activity.title}
                    </h3>
                    
                    {/* Description */}
                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                      {activity.description}
                    </p>
                    
                    {/* Metadata */}
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-xs text-gray-500">
                        <FiCalendar className="h-3 w-3 mr-2" />
                        {new Date(activity.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </div>
                      <div className="flex items-center text-xs text-gray-500">
                        <FiTag className="h-3 w-3 mr-2" />
                        {activity.department} • Year {activity.year}
                      </div>
                      <div className="flex items-center text-xs text-gray-500">
                        <FiImage className="h-3 w-3 mr-2" />
                        {activity.images?.length || 0} Image{activity.images?.length !== 1 ? 's' : ''}
                      </div>
                    </div>
                    
                    {/* Admin Comments */}
                    {activity.admin_comments && (
                      <div className={`mb-4 p-3 rounded-lg border-2 ${statusInfo.bgColor} border-${statusInfo.color.split('-')[1]}-200`}>
                        <p className="text-xs font-semibold uppercase tracking-wide mb-1">Admin Comments</p>
                        <p className="text-sm text-gray-700">{activity.admin_comments}</p>
                      </div>
                    )}
                    
                    {/* View Button */}
                    <div className="pt-4 border-t border-gray-200">
                      <div className="flex items-center text-blue-600 font-semibold text-sm group-hover:text-blue-700">
                        View Details
                        <FiArrowRight className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="max-w-md mx-auto">
              <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center">
                <FiPlus className="h-12 w-12 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">No achievements yet</h3>
              <p className="text-gray-600 mb-8">
                Start showcasing your accomplishments by sharing your first achievement
              </p>
              <Link
                to="/activities/create"
                className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200"
              >
                <FiPlus className="h-5 w-5 mr-2" />
                Create First Achievement
              </Link>
            </div>
          </div>
        )}

        {/* Modern Pagination */}
        {totalPages > 1 && (
          <div className="bg-white rounded-xl shadow-lg p-4 border border-gray-200">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-gray-700">
                Page <span className="font-bold text-blue-600">{currentPage}</span> of <span className="font-bold">{totalPages}</span>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border-2 border-gray-300 rounded-lg hover:bg-gray-50 hover:border-blue-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Previous
                </button>
                <button
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                  className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg hover:shadow-md transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Activities;
