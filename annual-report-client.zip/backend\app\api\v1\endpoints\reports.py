"""
Report generation endpoints
"""

from fastapi import APIRouter, Depends, HTTPException, status, Response
from typing import List, Optional
from app.models.report import Report, ReportCreate, ReportFilters, ReportStats
from app.services.report_service import ReportService
from app.services.database import get_database
from app.core.security import get_current_active_user, require_faculty_or_admin, TokenData
from motor.motor_asyncio import AsyncIOMotorDatabase
import os

router = APIRouter()

@router.get("/individual/{activity_id}", response_model=dict)
async def get_individual_report(
    activity_id: str,
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get individual activity report (HTML)"""
    report_service = ReportService(db)
    
    # Check if activity exists and user has access
    activity = await report_service.get_activity_for_report(activity_id)
    if not activity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Activity not found"
        )
    
    # Users can only view their own reports unless they're admin
    if (current_user.user_id != activity["user_id"] and 
        current_user.role != "admin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    # Generate HTML report
    html_content = await report_service.generate_individual_html(activity)
    return {"html": html_content}

@router.get("/individual/{activity_id}/pdf")
async def get_individual_report_pdf(
    activity_id: str,
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Download individual activity report as PDF"""
    report_service = ReportService(db)
    
    # Check if activity exists and user has access
    activity = await report_service.get_activity_for_report(activity_id)
    if not activity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Activity not found"
        )
    
    # Users can only view their own reports unless they're admin
    if (current_user.user_id != activity["user_id"] and 
        current_user.role != "admin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    # Generate PDF report
    pdf_path = await report_service.generate_individual_pdf(activity)
    
    if not os.path.exists(pdf_path):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate PDF"
        )
    
    # Return PDF file
    with open(pdf_path, "rb") as f:
        pdf_content = f.read()
    
    return Response(
        content=pdf_content,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=activity_{activity_id}_report.pdf"
        }
    )

@router.get("/group", response_model=dict)
async def get_group_report(
    department: Optional[str] = None,
    year: Optional[int] = None,
    type: Optional[str] = None,
    current_user: TokenData = Depends(require_faculty_or_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get group report (HTML)"""
    report_service = ReportService(db)
    
    # Faculty can only view their own department's reports
    if (current_user.role == "faculty" and 
        current_user.department != department):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot view other department's reports"
        )
    
    # Generate HTML report
    html_content = await report_service.generate_group_html(
        department=department,
        year=year,
        type=type
    )
    return {"html": html_content}

@router.get("/group/pdf")
async def get_group_report_pdf(
    department: Optional[str] = None,
    year: Optional[int] = None,
    type: Optional[str] = None,
    current_user: TokenData = Depends(require_faculty_or_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Download group report as PDF"""
    report_service = ReportService(db)
    
    # Faculty can only view their own department's reports
    if (current_user.role == "faculty" and 
        current_user.department != department):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot view other department's reports"
        )
    
    # Generate PDF report
    pdf_path = await report_service.generate_group_pdf(
        department=department,
        year=year,
        type=type
    )
    
    if not os.path.exists(pdf_path):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate PDF"
        )
    
    # Return PDF file
    with open(pdf_path, "rb") as f:
        pdf_content = f.read()
    
    filename = f"group_report_{department or 'all'}_{year or 'all'}.pdf"
    return Response(
        content=pdf_content,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )

@router.get("/stats", response_model=ReportStats)
async def get_report_stats(
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get report statistics"""
    report_service = ReportService(db)
    
    # Non-admin users can only see their own department's stats
    if current_user.role == "admin":
        stats = await report_service.get_all_stats()
    else:
        stats = await report_service.get_department_stats(current_user.department)
    
    return stats

@router.get("/", response_model=List[Report])
async def get_reports(
    skip: int = 0,
    limit: int = 100,
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get generated reports"""
    report_service = ReportService(db)
    
    # Non-admin users can only see their own reports
    if current_user.role == "admin":
        reports = await report_service.get_reports(skip=skip, limit=limit)
    else:
        reports = await report_service.get_user_reports(
            current_user.user_id, 
            skip=skip, 
            limit=limit
        )
    
    return reports

@router.post("/generate", response_model=Report)
async def generate_report(
    report_data: ReportCreate,
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Generate a new report"""
    report_service = ReportService(db)
    
    # Generate report
    report = await report_service.create_report(
        report_data, 
        current_user.user_id
    )
    
    return report

@router.get("/templates")
async def get_report_templates(
    current_user: TokenData = Depends(get_current_active_user)
):
    """Get available report templates"""
    templates = [
        {
            "id": "individual",
            "name": "Individual Activity Report",
            "description": "Report for a single activity"
        },
        {
            "id": "group",
            "name": "Group Report",
            "description": "Report for multiple activities"
        },
        {
            "id": "department",
            "name": "Department Report",
            "description": "Report for a department"
        },
        {
            "id": "yearly",
            "name": "Yearly Report",
            "description": "Annual report for the institution"
        }
    ]
    
    return {"templates": templates}
