import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { 
  FiActivity, 
  FiUsers, 
  FiFileText, 
  FiTrendingUp, 
  FiPlus, 
  FiEye,
  FiAward,
  FiCalendar,
  FiTarget
} from 'react-icons/fi';
import axios from 'axios';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const StudentDashboard = ({ isVisible }) => {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [recentActivities, setRecentActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Load stats
      const statsResponse = await axios.get('/api/v1/reports/stats');
      setStats(statsResponse.data);

      // Load recent activities
      const activitiesResponse = await axios.get('/api/v1/activities?page=1&size=5');
      setRecentActivities(activitiesResponse.data.activities || []);
      
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActivityTypeColor = (type) => {
    const colors = {
      social: '#3B82F6',
      sports: '#10B981',
      academic: '#8B5CF6',
      cultural: '#EC4899',
      technical: '#6366F1'
    };
    return colors[type] || '#6B7280';
  };

  if (loading) {
    return (
      <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center">
            <div className="spinner"></div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="dashboard" className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome section */}
        <div 
          data-animate
          className={`text-center mb-16 transition-all duration-1000 ${isVisible['dashboard-title'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          id="dashboard-title"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome back, <span className="text-blue-600">{user?.name}!</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Track your achievements, manage your activities, and showcase your journey at TKIET Warananagar.
          </p>
        </div>

        {/* Stats cards */}
        {stats && (
          <div 
            data-animate
            className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12 transition-all duration-1000 delay-200 ${isVisible['dashboard-stats'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            id="dashboard-stats"
          >
            <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <FiAward className="h-8 w-8 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">My Achievements</p>
                  <p className="text-2xl font-semibold text-gray-900">{stats.total_activities}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <FiTrendingUp className="h-8 w-8 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Approved</p>
                  <p className="text-2xl font-semibold text-gray-900">{stats.accepted_activities}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <FiTarget className="h-8 w-8 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">This Year</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {recentActivities.filter(a => new Date(a.created_at).getFullYear() === new Date().getFullYear()).length}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <FiCalendar className="h-8 w-8 text-orange-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Pending Review</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {recentActivities.filter(a => a.status === 'pending').length}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Activity Types Chart */}
          {stats?.activity_types && (
            <div 
              data-animate
              className={`bg-white rounded-xl shadow-lg p-6 transition-all duration-1000 delay-300 ${isVisible['dashboard-chart1'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
              id="dashboard-chart1"
            >
              <h3 className="text-lg font-medium text-gray-900 mb-4">My Achievement Types</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stats.activity_types}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {stats.activity_types.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={getActivityTypeColor(entry.type)} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div 
            data-animate
            className={`bg-white rounded-xl shadow-lg p-6 transition-all duration-1000 delay-400 ${isVisible['dashboard-actions'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            id="dashboard-actions"
          >
            <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-4">
              <Link
                to="/activities/create"
                className="flex items-center p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors group"
              >
                <FiPlus className="h-6 w-6 text-blue-600 mr-4" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900 group-hover:text-blue-700">Post New Achievement</h4>
                  <p className="text-sm text-gray-500">Share your latest accomplishment</p>
                </div>
              </Link>

              <Link
                to="/activities"
                className="flex items-center p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors group"
              >
                <FiActivity className="h-6 w-6 text-green-600 mr-4" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900 group-hover:text-green-700">View All Achievements</h4>
                  <p className="text-sm text-gray-500">Manage your submitted activities</p>
                </div>
              </Link>

              <Link
                to="/reports"
                className="flex items-center p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors group"
              >
                <FiFileText className="h-6 w-6 text-purple-600 mr-4" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900 group-hover:text-purple-700">Generate Report</h4>
                  <p className="text-sm text-gray-500">Create your achievement report</p>
                </div>
              </Link>
            </div>
          </div>
        </div>

        {/* Recent Achievements */}
        <div 
          data-animate
          className={`bg-white rounded-xl shadow-lg p-6 transition-all duration-1000 delay-500 ${isVisible['dashboard-recent'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          id="dashboard-recent"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-medium text-gray-900">Recent Achievements</h3>
            <Link
              to="/activities"
              className="text-blue-600 hover:text-blue-700 text-sm font-medium"
            >
              View all
            </Link>
          </div>

          {recentActivities.length > 0 ? (
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-gray-900">{activity.title}</h4>
                    <p className="text-sm text-gray-500 mt-1">{activity.description}</p>
                    <div className="flex items-center mt-2 space-x-4">
                      <span className={`type-badge type-${activity.type}`}>
                        {activity.type}
                      </span>
                      <span className={`status-badge status-${activity.status}`}>
                        {activity.status}
                      </span>
                      <span className="text-xs text-gray-500">
                        {new Date(activity.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Link
                      to={`/activities/${activity.id}`}
                      className="p-2 text-gray-400 hover:text-gray-600"
                    >
                      <FiEye className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <FiAward className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No achievements yet</h3>
              <p className="mt-1 text-sm text-gray-500">
                Start your journey by posting your first achievement.
              </p>
              <div className="mt-6">
                <Link
                  to="/activities/create"
                  className="btn-primary inline-flex items-center"
                >
                  <FiPlus className="h-4 w-4 mr-2" />
                  Post Achievement
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default StudentDashboard;
