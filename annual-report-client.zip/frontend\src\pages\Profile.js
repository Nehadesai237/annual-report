import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { FiUser, FiMail, FiPhone, FiMapPin, FiCalendar, FiEdit3, FiSave, FiX } from 'react-icons/fi';

const Profile = () => {
  const { user, updateUser, changePassword } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    department: user?.department || '',
    phone: user?.phone || '',
    student_id: user?.student_id || '',
    year_of_study: user?.year_of_study || ''
  });
  const [passwordData, setPasswordData] = useState({
    current_password: '',
    new_password: '',
    confirm_password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordData({ ...passwordData, [name]: value });
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const result = await updateUser(formData);
      if (result.success) {
        setIsEditing(false);
      }
    } catch (error) {
      console.error('Update error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordSave = async () => {
    if (passwordData.new_password !== passwordData.confirm_password) {
      alert('New passwords do not match');
      return;
    }

    setLoading(true);
    try {
      const result = await changePassword(passwordData);
      if (result.success) {
        setIsChangingPassword(false);
        setPasswordData({ current_password: '', new_password: '', confirm_password: '' });
      }
    } catch (error) {
      console.error('Password change error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setFormData({
      name: user?.name || '',
      department: user?.department || '',
      phone: user?.phone || '',
      student_id: user?.student_id || '',
      year_of_study: user?.year_of_study || ''
    });
    setIsEditing(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Profile Settings</h1>
        <p className="mt-2 text-gray-600">
          Manage your account information and preferences.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Overview */}
        <div className="lg:col-span-1">
          <div className="card">
            <div className="text-center">
              <div className="mx-auto h-24 w-24 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <FiUser className="h-12 w-12 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">{user?.name}</h3>
              <p className="text-gray-600 capitalize">{user?.role}</p>
              <p className="text-sm text-gray-500">{user?.department}</p>
              {user?.student_id && (
                <p className="text-sm text-gray-500">ID: {user.student_id}</p>
              )}
            </div>
            
            <div className="mt-6 space-y-4">
              <div className="flex items-center text-sm text-gray-600">
                <FiMail className="h-4 w-4 mr-3" />
                {user?.email}
              </div>
              {user?.phone && (
                <div className="flex items-center text-sm text-gray-600">
                  <FiPhone className="h-4 w-4 mr-3" />
                  {user.phone}
                </div>
              )}
              <div className="flex items-center text-sm text-gray-600">
                <FiMapPin className="h-4 w-4 mr-3" />
                {user?.department}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <FiCalendar className="h-4 w-4 mr-3" />
                Joined {new Date(user?.created_at).toLocaleDateString()}
              </div>
            </div>
          </div>
        </div>

        {/* Profile Details */}
        <div className="lg:col-span-2">
          <div className="card">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-medium text-gray-900">Personal Information</h2>
              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  className="btn-primary inline-flex items-center"
                >
                  <FiEdit3 className="h-4 w-4 mr-2" />
                  Edit Profile
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleCancel}
                    className="btn-secondary inline-flex items-center"
                  >
                    <FiX className="h-4 w-4 mr-2" />
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={loading}
                    className="btn-primary inline-flex items-center"
                  >
                    <FiSave className="h-4 w-4 mr-2" />
                    {loading ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              )}
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="form-label">Full Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    disabled={!isEditing}
                    className="form-input"
                  />
                </div>
                <div>
                  <label className="form-label">Department</label>
                  <input
                    type="text"
                    name="department"
                    value={formData.department}
                    onChange={handleChange}
                    disabled={!isEditing}
                    className="form-input"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="form-label">Phone Number</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    disabled={!isEditing}
                    className="form-input"
                    placeholder="Enter phone number"
                  />
                </div>
                {user?.role === 'student' && (
                  <div>
                    <label className="form-label">Student ID</label>
                    <input
                      type="text"
                      name="student_id"
                      value={formData.student_id}
                      onChange={handleChange}
                      disabled={!isEditing}
                      className="form-input"
                      placeholder="Enter student ID"
                    />
                  </div>
                )}
              </div>

              {user?.role === 'student' && (
                <div>
                  <label className="form-label">Year of Study</label>
                  <select
                    name="year_of_study"
                    value={formData.year_of_study}
                    onChange={handleChange}
                    disabled={!isEditing}
                    className="form-input"
                  >
                    <option value="">Select Year</option>
                    <option value="1">1st Year</option>
                    <option value="2">2nd Year</option>
                    <option value="3">3rd Year</option>
                    <option value="4">4th Year</option>
                  </select>
                </div>
              )}

              <div>
                <label className="form-label">Email Address</label>
                <input
                  type="email"
                  value={user?.email}
                  disabled
                  className="form-input bg-gray-50"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Email cannot be changed. Contact admin if needed.
                </p>
              </div>
            </div>
          </div>

          {/* Password Change */}
          <div className="card mt-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-medium text-gray-900">Change Password</h2>
              {!isChangingPassword ? (
                <button
                  onClick={() => setIsChangingPassword(true)}
                  className="btn-secondary inline-flex items-center"
                >
                  <FiEdit3 className="h-4 w-4 mr-2" />
                  Change Password
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={() => {
                      setIsChangingPassword(false);
                      setPasswordData({ current_password: '', new_password: '', confirm_password: '' });
                    }}
                    className="btn-secondary inline-flex items-center"
                  >
                    <FiX className="h-4 w-4 mr-2" />
                    Cancel
                  </button>
                  <button
                    onClick={handlePasswordSave}
                    disabled={loading}
                    className="btn-primary inline-flex items-center"
                  >
                    <FiSave className="h-4 w-4 mr-2" />
                    {loading ? 'Saving...' : 'Save Password'}
                  </button>
                </div>
              )}
            </div>

            {isChangingPassword && (
              <div className="space-y-6">
                <div>
                  <label className="form-label">Current Password</label>
                  <input
                    type="password"
                    name="current_password"
                    value={passwordData.current_password}
                    onChange={handlePasswordChange}
                    className="form-input"
                    placeholder="Enter current password"
                  />
                </div>
                <div>
                  <label className="form-label">New Password</label>
                  <input
                    type="password"
                    name="new_password"
                    value={passwordData.new_password}
                    onChange={handlePasswordChange}
                    className="form-input"
                    placeholder="Enter new password"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Password must be at least 8 characters with uppercase, lowercase, number, and special character.
                  </p>
                </div>
                <div>
                  <label className="form-label">Confirm New Password</label>
                  <input
                    type="password"
                    name="confirm_password"
                    value={passwordData.confirm_password}
                    onChange={handlePasswordChange}
                    className="form-input"
                    placeholder="Confirm new password"
                  />
                </div>
              </div>
            )}

            {!isChangingPassword && (
              <p className="text-gray-600">
                Click "Change Password" to update your password. Make sure to use a strong password.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;