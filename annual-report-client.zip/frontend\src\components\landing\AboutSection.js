import React from 'react';
import { FaRocket, FaLightbulb, FaHandsHelping } from 'react-icons/fa';

const AboutSection = ({ isVisible }) => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          data-animate
          className={`text-center mb-16 transition-all duration-1000 ${isVisible['about-title'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          id="about-title"
        >
           <h2 className="text-4xl font-bold text-gray-900 mb-4">About TKIET Warananagar</h2>
           <p className="text-xl text-gray-600 max-w-3xl mx-auto">
             Tatyasaheb Kore Institute of Engineering & Technology (An Autonomous Institute) 
             has been at the forefront of academic excellence, providing world-class engineering 
             education with a commitment to innovation and student success.
           </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div 
            data-animate
            className={`text-center p-6 rounded-lg bg-blue-50 transition-all duration-1000 delay-100 ${isVisible['about-mission'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            id="about-mission"
          >
            <FaRocket className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Our Mission</h3>
             <p className="text-gray-600">
               To provide quality engineering education and develop competent professionals 
               who can contribute to society and industry through innovation and excellence.
             </p>
          </div>
          
          <div 
            data-animate
            className={`text-center p-6 rounded-lg bg-green-50 transition-all duration-1000 delay-200 ${isVisible['about-vision'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            id="about-vision"
          >
            <FaLightbulb className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Our Vision</h3>
             <p className="text-gray-600">
               To be a leading autonomous institution in engineering education, 
               research, and innovation that shapes the future of technology and society.
             </p>
          </div>
          
          <div 
            data-animate
            className={`text-center p-6 rounded-lg bg-purple-50 transition-all duration-1000 delay-300 ${isVisible['about-values'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            id="about-values"
          >
            <FaHandsHelping className="h-12 w-12 text-purple-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Our Values</h3>
             <p className="text-gray-600">
               Excellence, integrity, innovation, autonomy, and commitment to 
               student success, research, and community development.
             </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
