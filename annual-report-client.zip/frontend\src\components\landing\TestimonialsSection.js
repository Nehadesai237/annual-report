import React, { useState, useEffect } from 'react';
import { FaStar, FaQuoteLeft } from 'react-icons/fa';

const TestimonialsSection = ({ isVisible }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const testimonials = [
    {
      id: 1,
      name: "Priya Sharma",
      role: "Computer Science Student",
       content: "TKIET Warananagar has provided me with excellent opportunities to grow both academically and personally. The autonomous status allows for innovative curriculum and the faculty is highly supportive.",
      rating: 5
    },
    {
      id: 2,
      name: "Rajesh Kumar",
      role: "Mechanical Engineering Alumni",
       content: "The practical approach to learning and industry exposure at TKIET Warananagar helped me secure a great job at a leading automotive company. The autonomous curriculum was very relevant.",
      rating: 5
    },
    {
      id: 3,
      name: "Dr. Anjali Patel",
      role: "Professor, Computer Science",
       content: "Teaching at TKIET Warananagar has been a rewarding experience. The autonomous status allows for innovative teaching methods and the students are highly motivated.",
      rating: 5
    }
  ];

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          data-animate
          className={`text-center mb-16 transition-all duration-1000 ${isVisible['testimonials-title'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          id="testimonials-title"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">What Our Community Says</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
             Hear from our students, alumni, and faculty about their experiences at TKIET Warananagar.
          </p>
        </div>
        
        <div className="relative">
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="w-full flex-shrink-0">
                  <div className="bg-gray-50 rounded-lg p-8 mx-4">
                    <div className="text-center">
                      <FaQuoteLeft className="h-8 w-8 text-blue-600 mx-auto mb-4" />
                      <p className="text-lg text-gray-700 mb-6 italic">"{testimonial.content}"</p>
                      <div className="flex justify-center mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <FaStar key={i} className="h-5 w-5 text-yellow-400" />
                        ))}
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-gray-600">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-blue-600' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
