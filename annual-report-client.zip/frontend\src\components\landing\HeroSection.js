import React from 'react';
import { 
  FaUsers, 
  FaGraduationCap, 
  FaTrophy, 
  FaAward,
  FaChevronDown,
  FaPlay,
  FaArrowRight
} from 'react-icons/fa';

const HeroSection = ({ isVisible, scrollToSection, user }) => {
  return (
    <section id="home" className="pt-16 bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div 
            data-animate
            className={`transition-all duration-1000 ${isVisible['hero-text'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            id="hero-text"
          >
            {user ? (
              <>
                <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                  Welcome back, <span className="text-blue-600">{user.name}!</span>
                </h1>
                <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                  Continue your journey of excellence at TKIET Warananagar. 
                  Share your achievements, track your progress, and showcase your growth.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <button 
                    onClick={() => scrollToSection('dashboard')}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center"
                  >
                    View Dashboard <FaArrowRight className="ml-2" />
                  </button>
                  <button 
                    onClick={() => scrollToSection('about')}
                    className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center"
                  >
                    <FaPlay className="mr-2" /> Explore More
                  </button>
                </div>
              </>
            ) : (
              <>
                <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                  Welcome to <span className="text-blue-600">TKIET Warananagar</span>
                </h1>
                <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                  Empowering minds, shaping futures. Discover excellence in engineering education 
                  with state-of-the-art facilities, experienced faculty, and a vibrant campus life.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <button 
                    onClick={() => scrollToSection('about')}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center"
                  >
                    Explore More <FaArrowRight className="ml-2" />
                  </button>
                  <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center">
                    <FaPlay className="mr-2" /> Watch Video
                  </button>
                </div>
              </>
            )}
          </div>
          <div 
            data-animate
            className={`transition-all duration-1000 delay-300 ${isVisible['hero-image'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            id="hero-image"
          >
            <div className="relative">
              <div className="bg-gradient-to-br from-blue-400 to-indigo-600 rounded-2xl p-8 text-white">
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-white/20 rounded-lg p-4 text-center">
                    <FaUsers className="h-8 w-8 mx-auto mb-2" />
                    <div className="text-2xl font-bold">5000+</div>
                    <div className="text-sm">Students</div>
                  </div>
                  <div className="bg-white/20 rounded-lg p-4 text-center">
                    <FaGraduationCap className="h-8 w-8 mx-auto mb-2" />
                    <div className="text-2xl font-bold">15+</div>
                    <div className="text-sm">Programs</div>
                  </div>
                  <div className="bg-white/20 rounded-lg p-4 text-center">
                    <FaTrophy className="h-8 w-8 mx-auto mb-2" />
                    <div className="text-2xl font-bold">100%</div>
                    <div className="text-sm">Placement</div>
                  </div>
                  <div className="bg-white/20 rounded-lg p-4 text-center">
                    <FaAward className="h-8 w-8 mx-auto mb-2" />
                    <div className="text-2xl font-bold">25+</div>
                    <div className="text-sm">Years</div>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 px-4 py-2 rounded-full text-sm font-bold">
                NAAC 'A' Grade
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex justify-center mb-8">
        <button 
          onClick={() => scrollToSection('about')}
          className="animate-bounce text-gray-400 hover:text-blue-600 transition-colors"
        >
          <FaChevronDown className="h-6 w-6" />
        </button>
      </div>
    </section>
  );
};

export default HeroSection;
