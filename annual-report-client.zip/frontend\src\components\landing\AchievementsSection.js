import React from 'react';
import { FaTrophy, FaAward, FaRocket, FaLightbulb } from 'react-icons/fa';

const AchievementsSection = ({ isVisible }) => {
  const achievements = [
    {
      id: 1,
      title: "NAAC 'A' Grade Accreditation",
      description: "Recognized for excellence in education and infrastructure",
      icon: FaTrophy,
      year: "2023",
      category: "Accreditation"
    },
    {
      id: 2,
      title: "Best Engineering College Award",
      description: "Awarded by Maharashtra State Government",
      icon: FaAward,
      year: "2022",
      category: "Recognition"
    },
    {
      id: 3,
      title: "100% Placement Record",
      description: "Outstanding placement achievements across all branches",
      icon: FaRocket,
      year: "2023",
      category: "Placement"
    },
    {
      id: 4,
      title: "Research Excellence",
      description: "Multiple research papers published in international journals",
      icon: FaLightbulb,
      year: "2023",
      category: "Research"
    }
  ];

  return (
    <section id="achievements" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          data-animate
          className={`text-center mb-16 transition-all duration-1000 ${isVisible['achievements-title'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          id="achievements-title"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Achievements</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Celebrating our milestones and recognition in the field of engineering education.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {achievements.map((achievement, index) => (
            <div 
              key={achievement.id}
              data-animate
              className={`bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-300 p-6 transform hover:-translate-y-2 transition-all duration-1000 delay-${index * 100} ${isVisible[`achievement-${achievement.id}`] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
              id={`achievement-${achievement.id}`}
            >
              <achievement.icon className="h-12 w-12 text-blue-600 mb-4" />
              <div className="text-sm text-blue-600 font-semibold mb-2">{achievement.category}</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{achievement.title}</h3>
              <p className="text-gray-600 text-sm mb-3">{achievement.description}</p>
              <div className="text-xs text-gray-500">{achievement.year}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AchievementsSection;
