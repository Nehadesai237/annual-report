import React from 'react';
import { FaUsers } from 'react-icons/fa';

const ActivitiesSection = ({ isVisible }) => {
  const activities = [
    {
      id: 1,
      title: "Robotics Club",
      description: "Building innovative robots and participating in competitions",
      participants: 45,
      category: "Technical",
      status: "Active"
    },
    {
      id: 2,
      title: "Coding Club",
      description: "Programming competitions and hackathons",
      participants: 120,
      category: "Technical",
      status: "Active"
    },
    {
      id: 3,
      title: "Drama Society",
      description: "Theatrical performances and cultural events",
      participants: 30,
      category: "Cultural",
      status: "Active"
    },
    {
      id: 4,
      title: "Environmental Club",
      description: "Sustainability initiatives and green campus projects",
      participants: 60,
      category: "Social",
      status: "Active"
    }
  ];

  return (
    <section id="activities" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          data-animate
          className={`text-center mb-16 transition-all duration-1000 ${isVisible['activities-title'] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
          id="activities-title"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Student Activities</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our vibrant campus life through various clubs, societies, and activities.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {activities.map((activity, index) => (
            <div 
              key={activity.id}
              data-animate
              className={`bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-300 p-6 transform hover:-translate-y-2 transition-all duration-1000 delay-${index * 100} ${isVisible[`activity-${activity.id}`] !== false ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
              id={`activity-${activity.id}`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="text-sm text-blue-600 font-semibold">{activity.category}</div>
                <div className="text-xs text-green-600 bg-green-100 px-2 py-1 rounded-full">{activity.status}</div>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{activity.title}</h3>
              <p className="text-gray-600 text-sm mb-3">{activity.description}</p>
              <div className="flex items-center text-xs text-gray-500">
                <FaUsers className="h-4 w-4 mr-1" />
                {activity.participants} members
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ActivitiesSection;
