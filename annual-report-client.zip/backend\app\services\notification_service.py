"""
Notification service for user notifications
"""

from typing import List, Optional
from datetime import datetime
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.models.notification import Notification, NotificationCreate

class NotificationService:
    """Notification service for database operations"""
    
    def __init__(self, db: AsyncIOMotorDatabase):
        self.db = db
        self.collection = db.notifications
    
    async def create_notification(
        self, 
        user_id: str, 
        title: str, 
        message: str, 
        type: str = "info"
    ) -> Notification:
        """Create a new notification"""
        notification_doc = {
            "user_id": user_id,
            "title": title,
            "message": message,
            "type": type,
            "read": False,
            "created_at": datetime.utcnow()
        }
        
        result = await self.collection.insert_one(notification_doc)
        notification_doc["_id"] = str(result.inserted_id)
        
        return Notification(**notification_doc)
    
    async def get_user_notifications(
        self, 
        user_id: str, 
        skip: int = 0, 
        limit: int = 50
    ) -> List[Notification]:
        """Get notifications for a user"""
        cursor = self.collection.find(
            {"user_id": user_id}
        ).skip(skip).limit(limit).sort("created_at", -1)
        
        notifications = []
        async for notification_doc in cursor:
            notification_doc["_id"] = str(notification_doc["_id"])
            notifications.append(Notification(**notification_doc))
        
        return notifications
    
    async def mark_as_read(self, notification_id: str, user_id: str) -> bool:
        """Mark notification as read"""
        result = await self.collection.update_one(
            {
                "_id": ObjectId(notification_id),
                "user_id": user_id
            },
            {"$set": {"read": True}}
        )
        
        return result.matched_count > 0
    
    async def mark_all_as_read(self, user_id: str) -> int:
        """Mark all notifications as read for a user"""
        result = await self.collection.update_many(
            {"user_id": user_id, "read": False},
            {"$set": {"read": True}}
        )
        
        return result.modified_count
    
    async def get_unread_count(self, user_id: str) -> int:
        """Get count of unread notifications"""
        return await self.collection.count_documents({
            "user_id": user_id,
            "read": False
        })
    
    async def delete_notification(self, notification_id: str, user_id: str) -> bool:
        """Delete a notification"""
        result = await self.collection.delete_one({
            "_id": ObjectId(notification_id),
            "user_id": user_id
        })
        
        return result.deleted_count > 0
    
    async def delete_old_notifications(self, days: int = 30) -> int:
        """Delete notifications older than specified days"""
        from datetime import timedelta
        
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        result = await self.collection.delete_many({
            "created_at": {"$lt": cutoff_date}
        })
        
        return result.deleted_count
