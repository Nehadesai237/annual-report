import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { FiFileText, FiDownload, FiEye, FiRefreshCw } from 'react-icons/fi';
import axios from 'axios';
import toast from 'react-hot-toast';

const Reports = () => {
  const { user } = useAuth();
  const [reports, setReports] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    type: '',
    department: '',
    year: ''
  });

  useEffect(() => {
    loadReports();
    loadStats();
  }, []);

  const loadReports = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/v1/reports');
      setReports(response.data);
    } catch (error) {
      console.error('Error loading reports:', error);
      toast.error('Failed to load reports');
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const response = await axios.get('/api/v1/reports/stats');
      setStats(response.data);
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const generateIndividualReport = async (activityId) => {
    try {
      const response = await axios.get(`/api/v1/reports/individual/${activityId}`);
      return response.data.html;
    } catch (error) {
      const message = error.response?.data?.detail || 'Failed to generate report';
      toast.error(message);
      throw error;
    }
  };

  const downloadIndividualPDF = async (activityId) => {
    try {
      const response = await axios.get(`/api/v1/reports/individual/${activityId}/pdf`, {
        responseType: 'blob'
      });
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `activity_${activityId}_report.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      toast.success('PDF downloaded successfully');
    } catch (error) {
      const message = error.response?.data?.detail || 'Failed to download PDF';
      toast.error(message);
    }
  };

  const generateGroupReport = async (department, year, type) => {
    try {
      const params = new URLSearchParams();
      if (department) params.append('department', department);
      if (year) params.append('year', year);
      if (type) params.append('type', type);
      
      const response = await axios.get(`/api/v1/reports/group?${params}`);
      return response.data.html;
    } catch (error) {
      const message = error.response?.data?.detail || 'Failed to generate report';
      toast.error(message);
      throw error;
    }
  };

  const downloadGroupPDF = async (department, year, type) => {
    try {
      const params = new URLSearchParams();
      if (department) params.append('department', department);
      if (year) params.append('year', year);
      if (type) params.append('type', type);
      
      const response = await axios.get(`/api/v1/reports/group/pdf?${params}`, {
        responseType: 'blob'
      });
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `group_report_${department || 'all'}_${year || 'all'}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      toast.success('PDF downloaded successfully');
    } catch (error) {
      const message = error.response?.data?.detail || 'Failed to download PDF';
      toast.error(message);
    }
  };

  const previewReport = (htmlContent) => {
    const newWindow = window.open('', '_blank');
    newWindow.document.write(htmlContent);
    newWindow.document.close();
  };

  const getStatusColor = (status) => {
    const colors = {
      generating: 'status-pending',
      completed: 'status-accepted',
      failed: 'status-rejected'
    };
    return colors[status] || 'status-pending';
  };

  const getTypeColor = (type) => {
    const colors = {
      individual: 'type-academic',
      group: 'type-social',
      department: 'type-technical',
      yearly: 'type-cultural'
    };
    return colors[type] || 'type-academic';
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <FiFileText className="h-8 w-8 mr-3 text-blue-600" />
            Reports
          </h1>
          <p className="mt-2 text-gray-600">
            Generate and download activity reports in various formats.
          </p>
        </div>
        <button
          onClick={loadReports}
          className="btn-secondary inline-flex items-center"
        >
          <FiRefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </button>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="card">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-semibold">T</span>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total Activities</p>
                <p className="text-2xl font-semibold text-gray-900">{stats.total_activities}</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 font-semibold">A</span>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Accepted</p>
                <p className="text-2xl font-semibold text-gray-900">{stats.accepted_activities}</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <span className="text-purple-600 font-semibold">D</span>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Departments</p>
                <p className="text-2xl font-semibold text-gray-900">{stats.departments?.length || 0}</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                  <span className="text-orange-600 font-semibold">R</span>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Reports</p>
                <p className="text-2xl font-semibold text-gray-900">{reports.length}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Report Generation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Individual Report */}
        <div className="card">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Individual Activity Report</h3>
          <p className="text-sm text-gray-600 mb-4">
            Generate a detailed report for a specific activity.
          </p>
          <div className="space-y-4">
            <div>
              <label className="form-label">Activity ID</label>
              <input
                type="text"
                className="form-input"
                placeholder="Enter activity ID"
                id="individual-activity-id"
              />
            </div>
            <div className="flex space-x-2">
              <button
                onClick={async () => {
                  const activityId = document.getElementById('individual-activity-id').value;
                  if (!activityId) {
                    toast.error('Please enter an activity ID');
                    return;
                  }
                  try {
                    const html = await generateIndividualReport(activityId);
                    previewReport(html);
                  } catch (error) {
                    // Error already handled in function
                  }
                }}
                className="btn-secondary text-sm"
              >
                <FiEye className="h-4 w-4 mr-1" />
                Preview
              </button>
              <button
                onClick={async () => {
                  const activityId = document.getElementById('individual-activity-id').value;
                  if (!activityId) {
                    toast.error('Please enter an activity ID');
                    return;
                  }
                  await downloadIndividualPDF(activityId);
                }}
                className="btn-primary text-sm"
              >
                <FiDownload className="h-4 w-4 mr-1" />
                Download PDF
              </button>
            </div>
          </div>
        </div>

        {/* Group Report */}
        <div className="card">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Group Report</h3>
          <p className="text-sm text-gray-600 mb-4">
            Generate a comprehensive report for multiple activities.
          </p>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="form-label">Department</label>
                <select
                  className="form-input"
                  value={filters.department}
                  onChange={(e) => setFilters({...filters, department: e.target.value})}
                >
                  <option value="">All Departments</option>
                  {stats?.departments?.map(dept => (
                    <option key={dept.department} value={dept.department}>
                      {dept.department}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="form-label">Year</label>
                <select
                  className="form-input"
                  value={filters.year}
                  onChange={(e) => setFilters({...filters, year: e.target.value})}
                >
                  <option value="">All Years</option>
                  <option value="2024">2024</option>
                  <option value="2023">2023</option>
                  <option value="2022">2022</option>
                </select>
              </div>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={async () => {
                  try {
                    const html = await generateGroupReport(filters.department, filters.year, filters.type);
                    previewReport(html);
                  } catch (error) {
                    // Error already handled in function
                  }
                }}
                className="btn-secondary text-sm"
              >
                <FiEye className="h-4 w-4 mr-1" />
                Preview
              </button>
              <button
                onClick={async () => {
                  await downloadGroupPDF(filters.department, filters.year, filters.type);
                }}
                className="btn-primary text-sm"
              >
                <FiDownload className="h-4 w-4 mr-1" />
                Download PDF
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Generated Reports */}
      <div className="card">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Generated Reports</h3>
        {reports.length > 0 ? (
          <div className="space-y-4">
            {reports.map((report) => (
              <div key={report.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-4 mb-2">
                      <h4 className="text-sm font-medium text-gray-900">{report.title}</h4>
                      <span className={`status-badge ${getStatusColor(report.status)}`}>
                        {report.status}
                      </span>
                      <span className={`type-badge ${getTypeColor(report.type)}`}>
                        {report.type}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{report.description}</p>
                    <div className="flex items-center space-x-6 text-xs text-gray-500">
                      <span>Generated: {new Date(report.generated_at).toLocaleDateString()}</span>
                      <span>Size: {report.file_size ? `${(report.file_size / 1024).toFixed(1)} KB` : 'N/A'}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {report.status === 'completed' && (
                      <button
                        onClick={() => {
                          if (report.file_path) {
                            window.open(`/api/v1/reports/${report.id}/download`, '_blank');
                          }
                        }}
                        className="btn-primary text-sm"
                      >
                        <FiDownload className="h-4 w-4 mr-1" />
                        Download
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <FiFileText className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No reports generated</h3>
            <p className="mt-1 text-sm text-gray-500">
              Generate your first report using the options above.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Reports;
