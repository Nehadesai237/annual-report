"""
User management endpoints
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from typing import List
from app.models.user import User, UserUpdate, UserRole, UserProfile
from app.services.user_service import UserService
from app.services.database import get_database
from app.core.security import get_current_active_user, require_admin, TokenData
from motor.motor_asyncio import AsyncIOMotorDatabase

router = APIRouter()

@router.get("/me", response_model=User)
async def get_current_user(
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get current user profile"""
    user_service = UserService(db)
    user = await user_service.get_by_id(current_user.user_id)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return user

@router.put("/me", response_model=User)
async def update_current_user(
    user_update: UserUpdate,
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Update current user profile"""
    user_service = UserService(db)
    
    # Check if user exists
    user = await user_service.get_by_id(current_user.user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Update user
    updated_user = await user_service.update_user(current_user.user_id, user_update)
    return updated_user

@router.get("/", response_model=List[User])
async def get_users(
    skip: int = 0,
    limit: int = 100,
    department: str = None,
    role: UserRole = None,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get all users (admin only)"""
    user_service = UserService(db)
    users = await user_service.get_users(
        skip=skip,
        limit=limit,
        department=department,
        role=role
    )
    return users

@router.get("/{user_id}", response_model=User)
async def get_user(
    user_id: str,
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get user by ID"""
    user_service = UserService(db)
    
    # Users can only view their own profile unless they're admin
    if current_user.user_id != user_id and current_user.role != UserRole.ADMIN.value:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    user = await user_service.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return user

@router.put("/{user_id}", response_model=User)
async def update_user(
    user_id: str,
    user_update: UserUpdate,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Update user (admin only)"""
    user_service = UserService(db)
    
    # Check if user exists
    user = await user_service.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Update user
    updated_user = await user_service.update_user(user_id, user_update)
    return updated_user

@router.delete("/{user_id}")
async def delete_user(
    user_id: str,
    current_user: TokenData = Depends(require_admin),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Delete user (admin only)"""
    user_service = UserService(db)
    
    # Check if user exists
    user = await user_service.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Cannot delete self
    if current_user.user_id == user_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot delete your own account"
        )
    
    # Delete user
    await user_service.delete_user(user_id)
    return {"message": "User deleted successfully"}

@router.get("/department/{department}/users", response_model=List[User])
async def get_users_by_department(
    department: str,
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get users by department"""
    user_service = UserService(db)
    
    # Users can only view users from their own department unless they're admin
    if (current_user.role != UserRole.ADMIN.value and 
        current_user.department != department):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot view users from other departments"
        )
    
    users = await user_service.get_users_by_department(department)
    return users

@router.get("/search", response_model=List[UserProfile])
async def search_users(
    q: str = Query(..., description="Search query (name or email)"),
    limit: int = 20,
    current_user: TokenData = Depends(get_current_active_user),
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Search users by name or email"""
    user_service = UserService(db)
    
    # Search users by name or email
    users = await user_service.search_users(query=q, limit=limit)
    
    # Convert to profile format
    profiles = []
    for user in users:
        profile = UserProfile(
            id=user.id,
            name=user.name,
            department=user.department,
            role=user.role,
            student_id=user.student_id,
            year_of_study=user.year_of_study,
            created_at=user.created_at
        )
        profiles.append(profile)
    
    return profiles